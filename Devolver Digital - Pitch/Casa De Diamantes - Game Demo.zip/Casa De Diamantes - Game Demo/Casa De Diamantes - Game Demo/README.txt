Thanks for checking out the game <3

CONTROLS:
WASD - Move
Space - Jump

Left Mousebutton - Shoot
Right Mousebutton - Reload
Left Control - Camera Look

2x Space - Double Jump
Shift - Dash

CHEATS:
F1 - Restart
F2-F5 - Level Teleport
J - Toggle HUD

Many visuals are not final!
A lot of systems are unfinished!
Levelstructure and encounters are subject to change!